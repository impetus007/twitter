import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SeleniumTest {

    @Test
    void setup(){

        // connnecting chrome
        System.setProperty("webdriver.chrome.driver","/Users/vishalsingh/Desktop/chromedriver");
        WebDriver Driver=new ChromeDriver();
        Driver.get("https://www.github.com");
        System.out.println("Page Title is : " + Driver.getTitle());

        Driver.quit();


    }
}
