package testNG;

import org.testng.annotations.Test;

public class Class1 {

    @Test
    public  void zemo(){
        System.out.println("hi i m vishal");
    }

    @Test
    public  void second(){
        System.out.println("second");
    }
    // only run after that on which it is dependent
    @Test(dependsOnMethods = {"zemo"})
    public void third(){
        System.out.println("It is dependent");
    }

    // we know it is bug and reported to High authority
    @Test(enabled = false)
    public void bug(){
        System.out.println("Skip that particular test case");
    }
    // timeout used for incase your method is taing time more than usaully
    @Test(timeOut = 5000)
    public void timeout(){
        System.out.println("this is time out test case");
    }

}
