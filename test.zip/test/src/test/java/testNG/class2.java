package testNG;

import org.testng.annotations.*;

public class class2 {


    @Test(groups = {"Smoke"})
    public void hlo(){
        System.out.println("i m from class2 with default");
    }
    @BeforeTest
    public void before(){
        System.out.println("this is first test whcih will run before any other file");
    }
    @AfterTest
    public  void after(){
        System.out.println("This will run at last/after every test performed");
    }

    @AfterSuite
    public void aftersuite(){
        System.out.println("I am last suite ");
    }
    @BeforeSuite
    public  void beforeSuite(){
        System.out.println("I am first suit");
    }
}
