import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowActivity {
    public static void main(String[] args) {

        // selenium Manager which handle this property
//        System.setProperty("webdriver.chrome.driver", "/Users/vishalsingh/Desktop/chromedriver");
        WebDriver driver=new ChromeDriver();
        driver.manage().window().maximize();
//        driver.maximize_window()
        driver.get("https://google.com");
        driver.navigate().to("https://rahulshettyacademy.com");
        driver.navigate().back();
        driver.navigate().forward();
    }
}
