import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Locators {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","/Users/vishalsingh/Desktop/chromedriver");
        WebDriver driver=new ChromeDriver();


        // implicit wait - % seconds time out
           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        // go to particular url
        driver.get("https://rahulshettyacademy.com/locatorspractice/");

        // find an element by id
        driver.findElement(By.id("inputUsername")).sendKeys("impetus");

        // find password element by name;
        driver.findElement(By.name("inputPassword")).sendKeys("rahulshettyacadem");


        //


        // check and uncheck checkbox
        WebElement checkbox=driver.findElement(By.id("chkboxOne"));

        WebElement checkbox2=driver.findElement(By.id("chkboxTwo"));

        if(!checkbox.isSelected()){
            checkbox.click();
        }else{
            System.out.println("checkbox is already checked");
        }

        if(!checkbox2.isSelected()){
            checkbox2.click();
        }else{
            System.out.println("checkbox done");
        }

        driver.findElement(By.className("signInBtn")).click();

        // catch if somethinh went wrong
        System.out.println(driver.findElement(By.cssSelector("p.error")).getText());

        // link
        driver.findElement(By.linkText("Forgot your password?")).click();

        // using xPath
        driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("impetus007");

        driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("impetus007@gmail.com");

        driver.findElement(By.xpath("//input[@type='text'][2]")).clear();

        driver.findElement(By.cssSelector("input[type='text']:nth-child(3)")).sendKeys("vishal@gmail.com");

        // Generating xpaths with parent to child tags traverse techniques

        driver.findElement(By.xpath("//form/input[3]")).sendKeys("7458939969");

        driver.findElement(By.cssSelector(".reset-pwd-btn")).click();

        // generating cssselector with parent to child tage traverse techniques
        System.out.println(driver.findElement(By.cssSelector("form p")).getText());




    }
}
