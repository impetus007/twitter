import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class DropDown1 {
    public static void main(String[] args) {

        ChromeOptions options=new ChromeOptions();
        options.addArguments("--disable-notifications");

        WebDriver driver=new ChromeDriver(options);

        // invoking the url
        driver.get("https://www.spicejet.com/");

        // find dropdwoon by id
        try{

        driver.findElement(By.xpath("//*[text()='1 Adult']")).click();
        Thread.sleep(5000);
        int i=1;
        while(i<5){
            driver.findElement(By.cssSelector(".css-76zvg2.r-homxoj.r-adyw6z.r-q4m81j")).click();

            i++;
        }
            System.out.println("hi");

        }catch (InterruptedException e){
            e.printStackTrace();
        }



    }
}
